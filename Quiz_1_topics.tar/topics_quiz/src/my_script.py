#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

m_speed = Twist()


def callback(msg):
    # print(len(msg.ranges))  # 720 lines
    focus_point = int(len(msg.ranges)/2)
    if msg.ranges[focus_point] < 29.5 or msg.ranges[focus_point + 60] < 29.5 \
            or msg.ranges[focus_point - 60] < 29.5:
        m_speed.angular.z = 1
        m_speed.linear.x = 0

    else:
        m_speed.angular.z = 0
        m_speed.linear.x = 0.5


rospy.init_node("topics_quiz_node")
rospy.Subscriber("/kobuki/laser/scan", LaserScan, callback)

pub = rospy.Publisher("/cmd_vel", Twist)

rate = rospy.Rate(10)

while not rospy.is_shutdown():
    pub.publish(m_speed)
    rate.sleep()
