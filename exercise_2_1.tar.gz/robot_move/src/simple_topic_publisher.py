#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

rospy.init_node('Jim')
pub = rospy.Publisher('cmd_vel', Twist)

m_speed = Twist()
m_speed.linear.x = 0.5
m_speed.angular.z = 0.75

rate = rospy.Rate(1)

while not rospy.is_shutdown():
    pub.publish(m_speed)
    rate.sleep()
