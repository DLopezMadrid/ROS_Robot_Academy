#! /usr/bin/env python

import rospy
from std_srvs.srv import Empty, EmptyResponse
from geometry_msgs.msg import Twist


def my_callback(request):
    print ("circle move")
    m_twist.linear.x = 0.25
    m_twist.angular.z = 0.25
    m_mover.publish(m_twist)
    return EmptyResponse()


rospy.init_node("service_move_bb8_in_circle_server")
my_service = rospy.Service("/my_bb8_service", Empty, my_callback)
m_twist = Twist()
m_mover = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
rospy.spin()
