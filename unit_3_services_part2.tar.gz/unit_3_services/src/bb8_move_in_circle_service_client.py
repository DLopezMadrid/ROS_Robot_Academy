#! /usr/bin/env python

import rospy
from std_srvs.srv import Empty, EmptyRequest

rospy.init_node("service_move_bb8_in_circle_client")
rospy.wait_for_service("/my_bb8_service")
move_bb8_serv = rospy.ServiceProxy("/my_bb8_service", Empty)

move_bb8_req = EmptyRequest()

move_bb8_serv(move_bb8_req)
