#! /usr/bin/env python

# Exercise 3.3

import rospy
from my_custom_srv_msg_pkg.srv import MyCustomServiceMessage
from my_custom_srv_msg_pkg.srv import MyCustomServiceMessageRequest

rospy.init_node("service_move_bb8_in_circle_custom_client")
rospy.wait_for_service("/move_bb8_in_circle_custom")
m_serv = rospy.ServiceProxy(
    "/move_bb8_in_circle_custom", MyCustomServiceMessage)
m_req = MyCustomServiceMessageRequest()
m_req.duration = 5
m_success = m_serv(m_req)
print (m_success)
