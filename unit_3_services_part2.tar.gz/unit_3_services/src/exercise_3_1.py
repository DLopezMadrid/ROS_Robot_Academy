#! /usr/bin/env python

import rospy
from iri_wam_reproduce_trajectory.srv import ExecTraj, ExecTrajRequest
import rospkg

rospy.init_node("mr_robot")
rospy.wait_for_service("/execute_trajectory")
move_arm_serv = rospy.ServiceProxy('/execute_trajectory', ExecTraj)

rospack = rospkg.RosPack()
traj = rospack.get_path(
    'iri_wam_reproduce_trajectory') + "/config/get_food.txt"

traj_req = ExecTrajRequest()
traj_req.file = traj
move_arm_serv(traj_req)
