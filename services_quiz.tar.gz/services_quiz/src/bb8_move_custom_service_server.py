#! /usr/bin/env python

# Exercise 3.3

import rospy
from my_custom_srv_msg_pkg.srv import MyCustomServiceMessage
from my_custom_srv_msg_pkg.srv import MyCustomServiceMessageResponse
from services_quiz.srv import BB8CustomServiceMessage
from services_quiz.srv import BB8CustomServiceMessageResponse
from geometry_msgs.msg import Twist
import time


rospy.init_node("service_move_bb8_in_circle_custom_server")
m_twist = Twist()


def my_callback(request):
    m_twist.angular.z = 0.25
    m_twist.linear.x = 0.25
    m_pub.publish(m_twist)
    time.sleep(request.duration)
    m_twist.angular.z = 0
    m_twist.linear.x = 0
    m_pub.publish(m_twist)
    m_response = MyCustomServiceMessageResponse()
    m_response.success = True
    return m_response


def my_callback_square(request):
    global m_z_rot
    m_twist.linear.x = 0
    m_twist.linear.y = 0
    m_pub.publish(m_twist)
    for i in xrange(request.repetitions):
        for j in xrange(4):
            m_twist.linear.x = 0
            m_twist.angular.z = 0
            m_pub.publish(m_twist)
            time.sleep(0.5)
            m_twist.linear.x = 0.5
            m_twist.angular.z = 0
            m_pub.publish(m_twist)
            time.sleep(request.side)
            m_twist.linear.x = 0
            m_pub.publish(m_twist)
            time.sleep(3)
            m_twist.angular.z = 0.25
            m_pub.publish(m_twist)
            time.sleep(3)

    m_twist.linear.x = 0
    m_twist.angular.z = 0
    m_pub.publish(m_twist)
    time.sleep(1)

    m_response = BB8CustomServiceMessageResponse()
    m_response.success = True
    return m_response


m_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
rospy.Service("/move_bb8_in_circle_custom",
              MyCustomServiceMessage, my_callback)
rospy.Service("/move_bb8_in_square_custom",
              BB8CustomServiceMessage, my_callback_square)
rospy.spin()
