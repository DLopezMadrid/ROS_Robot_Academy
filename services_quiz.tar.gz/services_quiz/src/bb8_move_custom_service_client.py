#! /usr/bin/env python

import rospy
from services_quiz.srv import BB8CustomServiceMessage
from services_quiz.srv import BB8CustomServiceMessageRequest

rospy.init_node("bb8_move_in_square_service_client")
rospy.wait_for_service("/move_bb8_in_square_custom")
m_service = rospy.ServiceProxy(
    "/move_bb8_in_square_custom", BB8CustomServiceMessage)
m_request = BB8CustomServiceMessageRequest()
m_request.side = 2.5
m_request.repetitions = 2
result = m_service(m_request)
m_request.side = 3.5
m_request.repetitions = 1
result = m_service(m_request)
