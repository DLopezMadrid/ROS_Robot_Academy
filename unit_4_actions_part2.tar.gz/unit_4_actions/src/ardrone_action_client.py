#! /usr/bin/env python

import rospy
import actionlib
from ardrone_as.msg import ArdroneAction, ArdroneGoal
from ardrone_as.msg import ArdroneFeedback, ArdroneResult
from geometry_msgs.msg import Twist

nImage = 1

PENDING = 0
ACTIVE = 1
DONE = 2
WARN = 3
ERROR = 4


def my_callback(feedback):
    global nImage
    print ("FB: new image received %d" % nImage)
    nImage += 1


rospy.init_node("ardrone_action_client")
rate = rospy.Rate(1)

client = actionlib.SimpleActionClient("/ardrone_action_server", ArdroneAction)
client.wait_for_server()

goal = ArdroneGoal()
goal.nseconds = 10

client.send_goal(goal, feedback_cb=my_callback)

m_state = client.get_state()

m_twist = Twist()
m_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)
count = 0

while m_state < DONE:
    print ("State %d" % m_state)
    m_state = client.get_state()
    if (count % 6) > 2:
        m_twist.angular.z = 0.5
    else:
        m_twist.angular.z = -0.5
    m_twist.linear.x = 0.5
    m_pub.publish(m_twist)
    count += 1
    rate.sleep()

if m_state >= DONE:
    rospy.loginfo("Finished with %d" % m_state)
