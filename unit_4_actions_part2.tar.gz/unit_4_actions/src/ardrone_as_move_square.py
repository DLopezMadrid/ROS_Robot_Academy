#! /usr/bin/env python

import rospy
import actionlib
from actionlib.msg import TestAction, TestActionGoal
from actionlib.msg import TestActionFeedback, TestActionResult
from geometry_msgs.msg import Twist


class ArdroneMoveClass():
    _feedback = TestActionFeedback()
    _result = TestActionResult()

    def __init__(self):
        self._as = actionlib.SimpleActionServer(
            "ardrone_move_as", TestAction, self.move_callback, False)
        self._as.start()

    def move_callback(self, goal):
        r = rospy.Rate(1)
        success = True
        sq_size = goal.goal

        rospy.loginfo("Starting square of size %d" % sq_size)

        m_twist = Twist()
        m_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

        m_twist.linear.x = 0
        m_twist.linear.y = 0
        m_twist.angular.z = 0
        m_pub.publish(m_twist)
        rospy.sleep(1)

        for i in xrange(4):
            if self._as.is_preempt_requested():
                rospy.loginfo("Goal cancelled")
                m_twist.linear.x = 0
                m_twist.linear.y = 0
                m_pub.publish(m_twist)
                success = False
                self._as.set_preempted()
                break

            m_direction = 1
            if i < 2:
                m_direction = -1
            m_twist.linear.x = 0.5 * (i % 2) * m_direction
            m_twist.linear.y = 0.5 * ((i + 1) % 2) * m_direction
            m_pub.publish(m_twist)
            self._feedback.feedback = i
            self._as.publish_feedback(self._feedback)
            rospy.sleep(sq_size)

        if success:
            m_twist.linear.x = 0.0
            m_twist.linear.y = 0.0
            m_pub.publish(m_twist)
            self._result.result = self._feedback.feedback
            rospy.loginfo("Success!!!")
            self._as.set_succeeded(self._result)


if __name__ == '__main__':
    rospy.init_node('ardrone_square_move')
    ArdroneMoveClass()
    rospy.spin()
